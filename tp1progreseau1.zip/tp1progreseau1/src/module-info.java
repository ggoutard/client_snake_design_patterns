/**
 * 
 */
/**
 * 
 */

module tp1progreseau {
    requires java.desktop;
	requires com.fasterxml.jackson.databind;
}

